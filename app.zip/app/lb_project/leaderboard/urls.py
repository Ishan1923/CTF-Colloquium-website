from django.urls import path
from .views import UpdateTeamScore, LeaderboardList

urlpatterns = [
    path('leaderboard/', UpdateTeamScore.as_view(), name = 'update_team_score'),
    path('Leaderboard/list/', LeaderboardList.as_view(), name = 'leaderboard_list'),
]